#ifndef STARWARS_H
#define STARWARS_H

#include <QDialog>

namespace Ui {
class starwars;
}

class starwars : public QDialog
{
    Q_OBJECT

public:
    explicit starwars(QWidget *parent = nullptr);
    ~starwars();

private slots:
    void on_starwars_accepted();

private:
    Ui::starwars *ui;
};

#endif // STARWARS_H
