#ifndef PERSPECTIVA_H
#define PERSPECTIVA_H

#include "imagenes.h"
#include <QDialog>

namespace Ui {
class perspectiva;
}

class perspectiva : public QDialog
{
    Q_OBJECT

public:
    explicit perspectiva(int nfoto, QWidget *parent = nullptr);
    ~perspectiva();

    int nfoto1;
    int nfoto2;
    Point2f p1[4];
    Point2f p2[4];
    int corresp[MAX_VENTANAS];

private slots:
    void on_listWidget_currentRowChanged(int currentRow);

    void on_perspectiva_rejected();

    void on_perspectiva_accepted();

private:
    Ui::perspectiva *ui;
};

#endif // PERSPECTIVA_H
