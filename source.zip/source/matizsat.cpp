#include "matizsat.h"
#include "ui_matizsat.h"
#include "imagenes.h"

// callback para que no se modifique la imagen
void  callback3(int event, int x, int y, int flags, void *_nfoto){
    //no tiene que hacer nada
}


MatizSat::MatizSat(int nfoto, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MatizSat)
{
    ui->setupUi(this);
    this->nfoto = nfoto;
    setMouseCallback(foto[nfoto].nombre, callback3);


    ui->horizontalSlider_2->setValue(200);
    ui->horizontalSlider_3->setValue(200);
}

MatizSat::~MatizSat()
{
    delete ui;
}


void MatizSat::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}



void MatizSat::on_spinBox_valueChanged(int value)
{
    ui->horizontalSlider->setValue(value);
}

void MatizSat::on_spinBox_2_valueChanged(int value)
{
    ui->horizontalSlider_2->setValue(value);
}

void MatizSat::on_spinBox_3_valueChanged(int value)
{
    ui->horizontalSlider_3->setValue(value);
}

void MatizSat::on_horizontalSlider_valueChanged(int value)
{
    ui->spinBox->setValue(value);
    if (ui->checkBox->isChecked())
        ver_matiz_sat_lum(nfoto, ui->horizontalSlider->value(),
                                 ui->horizontalSlider_2->value()/100.0,
                                 ui->horizontalSlider_3->value()/100.0);
}

void MatizSat::on_horizontalSlider_2_valueChanged(int value)
{
    ui->spinBox_2->setValue(value);
    if (ui->checkBox->isChecked())
        ver_matiz_sat_lum(nfoto, ui->horizontalSlider->value(),
                                 ui->horizontalSlider_2->value()/100.0,
                                 ui->horizontalSlider_3->value()/100.0);
}

void MatizSat::on_horizontalSlider_3_valueChanged(int value)
{
    ui->spinBox_3->setValue(value);
    if (ui->checkBox->isChecked())
        ver_matiz_sat_lum(nfoto, ui->horizontalSlider->value(),
                                 ui->horizontalSlider_2->value()/100.0,
                                 ui->horizontalSlider_3->value()/100.0);
}


void MatizSat::on_checkBox_stateChanged(int value)
{
    if (value)
        ver_matiz_sat_lum(nfoto, ui->horizontalSlider->value(),
                                 ui->horizontalSlider_2->value()/100.0,
                                 ui->horizontalSlider_3->value()/100.0);
    else {
        mostrar(nfoto);
    }
}


void MatizSat::on_MatizSat_accepted()
{
    ver_matiz_sat_lum(nfoto, ui->horizontalSlider->value(),
                             ui->horizontalSlider_2->value()/100.0,
                             ui->horizontalSlider_3->value()/100.0, true);
    set_callback(nfoto);
}

void MatizSat::on_MatizSat_rejected()
{
    mostrar(nfoto);
    set_callback(nfoto);
}
