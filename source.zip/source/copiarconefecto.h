#ifndef COPIARCONEFECTO_H
#define COPIARCONEFECTO_H

#include <QDialog>
#include "video.h"


enum { SUAVIZADO_GAUSSIANO    = 0,
       SUAVIZADO_MEDIA        = 1,
       SUAVIZADO_MEDIANA      = 2,
     };

namespace Ui {
class CopiarConEfecto;
}

class CopiarConEfecto : public QDialog
{
    Q_OBJECT

public:
    explicit CopiarConEfecto(QWidget *parent = nullptr);
    ~CopiarConEfecto();

protected:
    void changeEvent(QEvent *e);

private slots:

    void on_spinBox_valueChanged(int value);

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::CopiarConEfecto *ui;

    int modo; // Indica el modo: por cámara (0) o seleccionando vídeo (1)
    int camara; // Cámara seleccionada si se ha elegido la opción de grabar vídeo

    QString nombre_in;  // Nombre del vídeo de entrada si lo hubiese
    QString nombre_out; // Nombre del vídeo resultado

    list<int> efectos; // Lista de efectos a aplicar
};

#endif // COPIARCONEFECTO_H
