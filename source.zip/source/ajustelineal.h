#ifndef AJUSTELINEAL_H
#define AJUSTELINEAL_H

#include <QDialog>

namespace Ui {
class ajustelineal;
}

class ajustelineal : public QDialog
{
    Q_OBJECT

public:
    explicit ajustelineal(int nfoto, QWidget *parent = nullptr);
    ~ajustelineal();

private slots:
    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_2_valueChanged(int value);

    void on_checkBox_clicked();

    void on_ajustelineal_accepted();

    void on_ajustelineal_rejected();

private:
    Ui::ajustelineal *ui;
    int nfoto;
};

#endif // AJUSTELINEAL_H
