#include "ajustelineal.h"
#include "ui_ajustelineal.h"
#include "imagenes.h"

ajustelineal::ajustelineal(int nfoto, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajustelineal)
{
    ui->setupUi(this);
    this->nfoto = nfoto;
    ver_ajuste_lineal(nfoto, 1, 1);
}

ajustelineal::~ajustelineal()
{
    delete ui;
}

void ajustelineal::on_horizontalSlider_valueChanged(int value)
{
    if (ui->checkBox->isChecked())
        ver_ajuste_lineal(nfoto, ui->horizontalSlider->value(), ui->horizontalSlider_2->value());
}

void ajustelineal::on_horizontalSlider_2_valueChanged(int value)
{
    if (ui->checkBox->isChecked())
        ver_ajuste_lineal(nfoto, ui->horizontalSlider->value(), ui->horizontalSlider_2->value());
}

void ajustelineal::on_checkBox_clicked()
{
    if (ui->checkBox->isChecked())
        ver_ajuste_lineal(nfoto, ui->horizontalSlider->value(), ui->horizontalSlider_2->value());
    else {
        mostrar(nfoto);
    }
}

void ajustelineal::on_ajustelineal_accepted()
{
    ver_ajuste_lineal(nfoto, ui->horizontalSlider->value(), ui->horizontalSlider_2->value(), true);
}

void ajustelineal::on_ajustelineal_rejected()
{
    mostrar(nfoto);
}
