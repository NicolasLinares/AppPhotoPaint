#ifndef COLORFALSO_H
#define COLORFALSO_H
#include <QDialog>

#include "imagenes.h"
#include "opencv2/imgproc.hpp" // importamos para tener los distintos mapas de colores


namespace Ui {
class colorfalso;
}

class colorfalso : public QDialog
{
    Q_OBJECT

public:
    explicit colorfalso(int nfoto, int res, QWidget *parent = nullptr);
    ~colorfalso();

private slots:
    void on_colorfalso_accepted();

private:
    Ui::colorfalso *ui;
    int nfoto;
    int nres;
};

#endif // COLORFALSO_H
