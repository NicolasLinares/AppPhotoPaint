#include "perfilado.h"
#include "ui_perfilado.h"

#include "imagenes.h"


// callback para que no se modifique la imagen
void  callback6(int event, int x, int y, int flags, void *_nfoto){
    //no tiene que hacer nada
}


// Solo puede tomar los valores 1,3,5,7 pero el slider solo
// va de 1 en 1 (no me funciona si pongo el parámetro singlestep = 2)
// por lo que ponemos que el slider solo vaya de 1 a 4 y
// traducimos a los valores a los que le corresponde realmente.
// De la misma forma cuando modificamos el spinbox.

int Slider2SpinBox(int valor)
{
    int radio = valor;

    switch (valor) {
    case 2:
        radio = 3;
        break;
    case 3:
        radio = 5;
        break;
    case 4:
        radio = 7;
        break;
    }

    return radio;
}

int SpinBox2Slider(int valor)
{
    int radio = valor;

    switch (valor) {
    case 3:
        radio = 2;
        break;
    case 5:
        radio = 3;
        break;
    case 7:
        radio = 4;
        break;
    }

    return radio;
}



perfilado::perfilado(int nfoto, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::perfilado)
{
    ui->setupUi(this);
    this->nfoto = nfoto;
    setMouseCallback(foto[nfoto].nombre, callback6, this);
}

perfilado::~perfilado()
{
    delete ui;
}

void perfilado::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void perfilado::on_spinBox_valueChanged(int value)
{
    ui->horizontalSlider->setValue(value);
}

void perfilado::on_spinBox_2_valueChanged(int value)
{
    value = SpinBox2Slider(value);
    ui->horizontalSlider_2->setValue(value);
}


void perfilado::on_horizontalSlider_valueChanged(int value)
{
    int radio = Slider2SpinBox(ui->horizontalSlider_2->value());

    ui->spinBox->setValue(value);
    if (ui->checkBox->isChecked())
        ver_perfilado(nfoto,
                      radio,
                      ui->horizontalSlider->value());
}

void perfilado::on_horizontalSlider_2_valueChanged(int value)
{
    int radio = Slider2SpinBox(value);

    ui->spinBox_2->setValue(radio);
    if (ui->checkBox->isChecked())
        ver_perfilado(nfoto,
                      radio,
                      ui->horizontalSlider->value());
}

void perfilado::on_checkBox_stateChanged(int value)
{
    int radio = Slider2SpinBox(ui->horizontalSlider_2->value());

    if (value)
        ver_perfilado(nfoto,
                      radio,
                      ui->horizontalSlider->value());
    else
        mostrar(nfoto);
}

void perfilado::on_buttonBox_accepted()
{
    int radio = Slider2SpinBox(ui->horizontalSlider_2->value());

    ver_perfilado(nfoto,
                  radio,
                  ui->horizontalSlider->value(),
                  true);
    close();
    set_callback(nfoto);
}

void perfilado::on_buttonBox_rejected()
{
    mostrar(nfoto);
    set_callback(nfoto);
    close();
}

void perfilado::on_perfilado_finished(int result)
{
    on_buttonBox_rejected();
}
