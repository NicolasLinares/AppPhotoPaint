#ifndef MATIZSAT_H
#define MATIZSAT_H

#include <QDialog>

namespace Ui {
class MatizSat;
}

class MatizSat : public QDialog
{
    Q_OBJECT

public:
    explicit MatizSat(int nfoto, QWidget *parent = nullptr);
    ~MatizSat();

protected:
    void changeEvent(QEvent *e);

private slots:
    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_2_valueChanged(int value);

    void on_checkBox_stateChanged(int arg1);

    void on_horizontalSlider_3_valueChanged(int value);

    void on_spinBox_valueChanged(int arg1);

    void on_spinBox_2_valueChanged(int arg1);

    void on_spinBox_3_valueChanged(int arg1);

    void on_MatizSat_accepted();

    void on_MatizSat_rejected();

private:
    int nfoto;
    Ui::MatizSat *ui;
};

#endif // MATIZSAT_H
