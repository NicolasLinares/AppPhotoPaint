#include "pinchar.h"
#include "ui_pinchar.h"


void callback2 (int event, int x, int y, int flags, void *_p)
{
    if (flags==EVENT_FLAG_LBUTTON){
        Pinchar *ppi = (Pinchar*) _p;
        ppi->centro.x = x;
        ppi->centro.y = y;
        ppi->actualizar();
    }
}

void Pinchar::actualizar()
{
    if (ui->checkBox->isChecked())
        ver_pinchar(nfoto, centro, grado, tam);
}

Pinchar::Pinchar(int nfoto, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Pinchar)
{
    ui->setupUi(this);
    this->nfoto = nfoto;
    centro = Point(foto[nfoto].img.cols/2, foto[nfoto].img.rows/2);
    grado = 25*0.00065;
    tam = 250;
    ver_pinchar(nfoto, centro, grado, tam);
    setMouseCallback(foto[nfoto].nombre, callback2, this);
}

Pinchar::~Pinchar()
{
    delete ui;
}

void Pinchar::on_horizontalSlider_valueChanged(int value)
{
    grado= value*0.00065;
    if (ui->checkBox->isChecked())
        ver_pinchar(nfoto, centro, grado, tam);
}

void Pinchar::on_horizontalSlider_2_valueChanged(int value)
{
    tam= value;
    if (ui->checkBox->isChecked())
        ver_pinchar(nfoto, centro, grado, tam);
}


void Pinchar::on_checkBox_clicked()
{
    if (ui->checkBox->isChecked())
        ver_pinchar(nfoto, centro, grado, tam);
    else
        mostrar(nfoto);

}

void Pinchar::on_Pinchar_accepted()
{
    ver_pinchar(nfoto, centro, grado, tam, true);
    set_callback(nfoto);
}

void Pinchar::on_Pinchar_rejected()
{
    mostrar(nfoto);
    set_callback(nfoto);
}
