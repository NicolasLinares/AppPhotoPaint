#ifndef BAJORRELIEVE_H
#define BAJORRELIEVE_H

#include <QDialog>

namespace Ui {
class bajorrelieve;
}

class bajorrelieve : public QDialog
{
    Q_OBJECT

public:
    explicit bajorrelieve(int nfoto, int nres, QWidget *parent = nullptr);
    ~bajorrelieve();

private slots:
    void on_horizontalSlider_valueChanged(int value);

    void on_dial_valueChanged(int value);

    void on_bajorrelieve_accepted();

    void on_bajorrelieve_rejected();

    void on_checkBox_stateChanged(int arg1);

private:
    Ui::bajorrelieve *ui;
    int nfoto;
    int nres;
};

#endif // BAJORRELIEVE_H
