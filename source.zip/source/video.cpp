//---------------------------------------------------------------------------

#include "video.h"
#include <math.h>
#include <QMessageBox>
#include <QFileDialog>

#include "copiarconefecto.h"

///////////////////////////////////////////////////////////////////
/////////  VARIABLES GLOBALES PRIVADAS               //////////////
///////////////////////////////////////////////////////////////////

static VideoCapture camara;
// Capturador de cámara usado actualmente

static Mat img_media;
// Imagen media acumulada de la cámara, con profundidad 32F

static int frames_img_media;
// Número de frames que se han acumulado en la media img_media

string FiltroVideo= "Todos los formatos (*.avi *.mpg *.wmv *.mov);;Archivos AVI (*.avi);;Archivos MPG (*.mpg *.mpeg);;Archivos WMV (*.wmv);;Archivos MOV (*.mov);;Otros (*.*)";

///////////////////////////////////////////////////////////////////
/////////  FUNCIONES DE PROCESAMIENTO DE VIDEO       //////////////
///////////////////////////////////////////////////////////////////

void rotar_video (int nfoto, string nombre, int modo, int nframes, int codec, double fps)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada && !nombre.empty() && nframes>0);
    Mat rotada;
    rotar_angulo(nfoto, rotada, 0, 1, modo);
    VideoWriter writer(nombre, codec, fps, rotada.size());
    if (writer.isOpened()) {
        for (int i= 0; i<=nframes; i++) {
            rotar_angulo(nfoto, rotada, i*360.0/nframes, 1, modo);
            namedWindow("Imagen a vídeo - Rotación", WINDOW_NORMAL);
            imshow("Imagen a vídeo - Rotación", rotada);
            waitKey(1);
            writer << rotada;
        }
        writer.release();
        destroyWindow("Imagen a vídeo - Rotación");
    }
}

//---------------------------------------------------------------------------

int inic_camara (int numero)
{
    if (camara.isOpened())
        camara.release();
    camara.open(numero);
    if (camara.isOpened()) {
        Mat img;
        namedWindow("Imagen de cámara", WINDOW_NORMAL);
        camara >> img;
        resizeWindow("Imagen de cámara", img.size().width, img.size().height);
        imshow("Imagen de cámara", img);
        return int(1000.0/30);
    }
    else
        return 0;
}

//---------------------------------------------------------------------------

void fin_camara (void)
{
    if (camara.isOpened()) {
        camara.release();
        namedWindow("Imagen de cámara",WINDOW_NORMAL);
        destroyWindow("Imagen de cámara");
    }
    namedWindow("Imagen media",WINDOW_NORMAL);
    destroyWindow("Imagen media");
}

//---------------------------------------------------------------------------

void acumular_media (bool primera)
{
    assert(camara.isOpened());
    Mat frame;
    camara >> frame;
    namedWindow("Imagen de cámara", WINDOW_NORMAL);
    imshow("Imagen de cámara", frame);
    if (primera) {
        frames_img_media= 1;
        frame.convertTo(img_media, CV_32FC3);
    }
    else {
        frames_img_media++;
        Mat frame32F;
        frame.convertTo(frame32F, CV_32FC3);
        img_media= frame32F + img_media;
        img_media.convertTo(frame, CV_8UC3, 1.0/frames_img_media);
    }
    namedWindow("Imagen media", WINDOW_NORMAL);
    imshow("Imagen media", frame);
}

//---------------------------------------------------------------------------

void media_a_nueva (int nfoto)
{
    Mat res(img_media.size(), CV_8UC3);
    img_media.convertTo(res, CV_8UC3, 1.0/frames_img_media);
    crear_nueva (nfoto, res);
}

//---------------------------------------------------------------------------

void mostrar_camara (void)
{
    Mat img;
    camara >> img;
    namedWindow("Imagen de cámara", WINDOW_NORMAL);
    imshow("Imagen de cámara", img);
}

//---------------------------------------------------------------------------

void capturar_de_camara(int ncamara, int nfoto)
{
    VideoCapture cap(ncamara);
    if (!cap.isOpened())
        QMessageBox::warning(NULL, "Error al abrir la cámara", "No se ha podido abrir la cámara" );
    else {
        Mat img;
        int tecla = -1;
        while(cap.read(img) && (tecla = waitKey(1)) == -1)
        {
            namedWindow("Capturar de cámara (ESC para salir)", 0);
            imshow("Capturar de cámara (ESC para salir)", img);
        }
        if (tecla != 27 && tecla != -1)
            crear_nueva(nfoto, img);
        destroyWindow("Capturar de cámara (ESC para salir)");

    }

}

//---------------------------------------------------------------------------

void ver_movimiento(string nombre, int nres)
{
    VideoCapture cap;
    if (!cap.open(nombre))
    {
        QMessageBox::warning(NULL, "Error al abrir el vídeo", QString::fromStdString("No se ha podido abrir el archivo " + nombre) );
        return;
    }

    Mat frame0, frame1;
    if (!cap.read(frame0) || !cap.read(frame1))
    {
        QMessageBox::warning(NULL, "Error al abrir el vídeo", QString::fromStdString("No se ha podido leer el archivo " + nombre) );
        return;
    }

    int tecla = 27; // tecla Esc

    Mat acum(frame0.size(), CV_32SC3, CV_RGB(0,0,0)); //inicializada a 0
    while(cap.read(frame0) && (tecla = waitKey(1)) == -1) // leemos y mientras no se pulse una tecla
    {
        Mat dif;
        absdiff(frame0, frame1, dif);
        //para hacer la suma hay que pasar dif a 32S (cambiar de profundidad)
        Mat dif32;
        dif.convertTo(dif32, CV_32S);
        acum += dif32;
        namedWindow("Vídeo", 0);
        imshow("Vídeo", frame0);
        frame0.copyTo(frame1);

        Mat tmp;
        normalize(acum, tmp, 255, 0, NORM_MINMAX);
        Mat res;
        tmp.convertTo(res, CV_8U);
        namedWindow("Movimiento", 0);
        imshow("Movimiento", res);
    }

    if (tecla != 27)
    {
        //normalizamos para que la imagen vaya de 0 a 255
        normalize(acum, acum, 255, 0, NORM_MINMAX);
        //pero sigue siendo de 32S la tenemos que volver a pasar a 8U
        Mat res;
        acum.convertTo(res, CV_8U);
        crear_nueva(nres, res);
        destroyWindow("Vídeo");
        destroyWindow("Movimiento");
    }

}

//---------------------------------------------------------------------------

void ver_copiar_con_efectos(int modo, String nombre_in, int camara, String nombre_out, list<int> efectos, String aplicar,int codec)
{
    VideoCapture vc;
    QString nombre_ventana;

    if (modo == 0)
    {
        vc.open(camara);
    }
    else
    {
        if (!vc.open(nombre_in))
        {
            QMessageBox::warning(NULL, "Error al abrir el vídeo", QString::fromStdString("No se ha podido abrir el archivo " + nombre_in) );
            return;
        }
    }

    Mat frame, res;
    if (!vc.read(frame))
    {
        QMessageBox::warning(NULL, "Error en el vídeo", QString::fromStdString("No se ha podido leer el archivo ") );
        return;
    }

    VideoWriter writer(nombre_out, codec, 30, frame.size());
    if (writer.isOpened())
    {
        int tecla = 27;

        namedWindow("Vídeo original (Pulsa Esc para terminar)", 0);
        moveWindow("Vídeo original (Pulsa Esc para terminar)", 200, 200);
        namedWindow("Vídeo con efectos (Pulsa Esc para terminar)", 0);
        moveWindow("Vídeo con efectos (Pulsa Esc para terminar)", 700, 200);

        while((tecla = waitKey(1)) != 27)
        {
            list<int>::iterator it;
            for (it = efectos.begin(); it != efectos.end(); it++) {
                // Se transforma el frame aplicando los efectos deseados
                switch (*it) {
                case SUAVIZADO_GAUSSIANO:
                    GaussianBlur(frame, res, Size(15, 15), 0);
                    break;
                case SUAVIZADO_MEDIA:
                    blur(frame, res, Size(15, 15));
                    break;
                case SUAVIZADO_MEDIANA:
                    medianBlur(frame, res, 15);
                    break;
                }
            }

            imshow("Vídeo original (Pulsa Esc para terminar)", frame);
            imshow("Vídeo con efectos (Pulsa Esc para terminar)", res);

            writer << res;

            if (!vc.read(frame))
                break;
        }

        vc.release();
        writer.release();
        destroyWindow("Vídeo original (Pulsa Esc para terminar)");
        destroyWindow("Vídeo con efectos (Pulsa Esc para terminar)");

        QMessageBox::information(NULL, "Información", "Se han añadido los siguientes efectos: \n" + QString::fromStdString(aplicar));

    }
}

//---------------------------------------------------------------------------

Mat perspectiva_video(Mat img, Size tam)
{
    Point2f p1[4] = {Point2f(0,0), Point2f(600, 0), Point2f(600, 400), Point2f(0, 400)};

    int w= tam.width, h=tam.height;
    Point2f p2[4]  = {Point2f(w*0.4,0), Point2f(w*0.6, 0), Point2f(w, h), Point2f(0, h)};

    Mat M = getPerspectiveTransform(p1, p2);

    Mat res;
    warpPerspective(img,res, M, tam, INTER_CUBIC);

    return res;
}

void ver_star_wars(int nfoto, string nombre, QString cadena, int nframes, int codec, double fps)
{
    VideoWriter vw(nombre, codec, fps, foto[nfoto].img.size());
    if (vw.isOpened())
    {
        Mat imgtexto = generar_texto(cadena, CV_RGB(255, 255, 0));
        for (int i = 0; i <= nframes; i++)
        {
            Mat roi = imgtexto(Rect(0, i*(imgtexto.rows-400)/nframes, 600, 400));
            Mat frame = perspectiva_video(roi, foto[nfoto].img.size());
            frame += foto[nfoto].img;

            namedWindow( "Star Wars", 0);
            imshow("Star Wars", frame);
            vw.write(frame);
            waitKey(1);

        }
        vw.release();
    }


}
