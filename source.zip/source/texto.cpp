#include "texto.h"
#include "ui_texto.h"

#include "imagenes.h"


void  callback7(int event, int x, int y, int flags, void *_nfoto){
    //no tiene que hacer nada
}

void texto::actualizar_imagen(bool guardar)
{
    cadena = ui->plainTextEdit->toPlainText();
    posicion = Point(ui->spinBox_2->value(), ui->spinBox_3->value());
    tam = ui->spinBox->value();
    transparencia = ui->spinBox_4->value();
    ver_texto(nfoto, cadena, posicion, tam,  color_texto, aplicar_sombreado, color_sombra, (transparencia-1)/10.0, guardar);
}

texto::texto(int nfoto, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::texto)
{
    ui->setupUi(this);
    this->nfoto = nfoto;

    this->aplicar_sombreado = 1;
    this->transparencia = 5;

    // se establece el límite de la posicion de la imagen para que el usuario solo pueda
    // poner el texto dentro de la misma
    ui->spinBox_2->setMaximum(foto[nfoto].img.cols);
    ui->spinBox_3->setMaximum(foto[nfoto].img.rows);

    ui->spinBox_4->setValue(transparencia);

    // Establecemos los colores iniciales
    ui->pushButton->setStyleSheet("background-color: rgb(255,0,0)");
    this->color_texto = CV_RGB(255,0,0);

    ui->pushButton_2->setStyleSheet("background-color: rgb(0,0,0)");
    this->color_sombra = CV_RGB(0, 0, 0);

    // se establece un callback para que no se modifique la imagen
    // al pasar el ratón por encima
    setMouseCallback(foto[nfoto].nombre, callback7, this);

    actualizar_imagen(false);
}

texto::~texto()
{
    delete ui;
}

void texto::on_pushButton_clicked()
{
    QColor color = QColorDialog::getColor();
    if (color.isValid()) {
        QString estilo= "background-color: rgb(";
        estilo+= QString::number(color.red())+",";
        estilo+= QString::number(color.green())+",";
        estilo+= QString::number(color.blue())+")";
        ui->pushButton->setStyleSheet(estilo);
        color_texto = CV_RGB(color.red(), color.green(), color.blue());
    }

    actualizar_imagen(false);
}

void texto::on_pushButton_2_clicked()
{
    QColor color = QColorDialog::getColor();
    if (color.isValid()) {
        QString estilo= "background-color: rgb(";
        estilo+= QString::number(color.red())+",";
        estilo+= QString::number(color.green())+",";
        estilo+= QString::number(color.blue())+")";
        ui->pushButton_2->setStyleSheet(estilo);
        color_sombra = CV_RGB(color.red(), color.green(), color.blue());
    }

    actualizar_imagen(false);
}

void texto::on_texto_accepted()
{
    cadena = ui->plainTextEdit->toPlainText();

    if (cadena.isEmpty())
        return;

    actualizar_imagen(true);

    set_callback(nfoto); // se devuelve el callback
}

void texto::on_checkBox_stateChanged(int value)
{
    aplicar_sombreado = value;
    actualizar_imagen(false);
}

void texto::on_plainTextEdit_textChanged()
{
    actualizar_imagen(false);
}

void texto::on_spinBox_valueChanged(int arg1)
{
    actualizar_imagen(false);
}

void texto::on_spinBox_4_valueChanged(int arg1)
{
    actualizar_imagen(false);
}

void texto::on_spinBox_2_valueChanged(int arg1)
{
    actualizar_imagen(false);
}

void texto::on_spinBox_3_valueChanged(int arg1)
{
    actualizar_imagen(false);
}

void texto::on_texto_rejected()
{
    mostrar(nfoto);
    set_callback(nfoto);
    close();
}

void texto::on_texto_finished(int result)
{
    on_texto_rejected();
}

