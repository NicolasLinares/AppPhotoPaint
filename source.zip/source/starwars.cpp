#include "starwars.h"
#include "ui_starwars.h"
#include "video.h"
#include "starwars.h"
#include <QFileDialog>
starwars::starwars(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::starwars)
{
    ui->setupUi(this);
}

starwars::~starwars()
{
    delete ui;
}

void starwars::on_starwars_accepted()
{
    int codigocc;
    QString cad= ui->comboBox->currentText();
    if (cad=="DEFAULT")
        codigocc= VideoWriter::fourcc('D','I','V','X');
    else {
        string cadena= cad.toLatin1().data();
        codigocc = VideoWriter::fourcc(cadena[0], cadena[1], cadena[2], cadena[3]);
    }

    if (foto_activa() == -1)
        return;

    QString nombre = QFileDialog::getSaveFileName();
    if (nombre.isEmpty())
        return;
    ver_star_wars(foto_activa(),
                  nombre.toLatin1().data(),
                  ui->plainTextEdit->toPlainText(),
                  ui->spinBox->value(),
                  codigocc,
                  ui->doubleSpinBox->value());
}
