#include "suavizados.h"
#include "ui_suavizados.h"

#include "imagenes.h"

// callback para que no se modifique la imagen
void  callback5(int event, int x, int y, int flags, void *_nfoto){
    //no tiene que hacer nada
}


suavizados::suavizados(int tipo, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::suavizados)
{
    ui->setupUi(this);
    nfoto= foto_activa();
    num_tipo= tipo;
    if (parent)
        move(parent->x()+DESP_X_HIJO, parent->y()+DESP_Y_HIJO);

    if (num_tipo == 3)
    {
        ui->spinBox_2->setEnabled(false);
        ui->horizontalSlider_2->setEnabled(false);
    }

    setMouseCallback(foto[nfoto].nombre, callback5, this);
}

suavizados::~suavizados()
{
    delete ui;
}

void suavizados::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void suavizados::on_spinBox_valueChanged(int valor)
{
    ui->horizontalSlider->setValue(valor);
}

void suavizados::on_spinBox_2_valueChanged(int valor)
{
    ui->horizontalSlider_2->setValue(valor);
}

void suavizados::on_horizontalSlider_valueChanged(int value)
{
    ui->spinBox->setValue(value);
    if (ui->checkBox->isChecked())
        ver_suavizado(nfoto, num_tipo,
                      ui->horizontalSlider->value()*2-1,
                      ui->horizontalSlider_2->value()*2-1);
}

void suavizados::on_horizontalSlider_2_valueChanged(int value)
{
    ui->spinBox_2->setValue(value);
    if (ui->checkBox->isChecked())
        ver_suavizado(nfoto, num_tipo,
                      ui->horizontalSlider->value()*2-1,
                      ui->horizontalSlider_2->value()*2-1);
}

void suavizados::on_checkBox_stateChanged(int value)
{
    if (value)
        ver_suavizado(nfoto, num_tipo,
                      ui->horizontalSlider->value()*2-1,
                      ui->horizontalSlider_2->value()*2-1);
    else
        mostrar(nfoto);
}

void suavizados::on_suavizados_accepted()
{
    ver_suavizado(nfoto, num_tipo,
                  ui->horizontalSlider->value()*2-1,
                  ui->horizontalSlider_2->value()*2-1, true);
    set_callback(nfoto);
}

void suavizados::on_suavizados_rejected()
{
    mostrar(nfoto);
    set_callback(nfoto);
}
