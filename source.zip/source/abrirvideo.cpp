#include "abrirvideo.h"
#include "ui_abrirvideo.h"
#include "QMessageBox"
#include "imagenes.h"

AbrirVideo::AbrirVideo(std::string nombre, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AbrirVideo)
{
    ui->setupUi(this);
    if (!vc.open(nombre))  //si no se puede abrir lo cerramos
    {
        QMessageBox::warning(this, "Error al abrir el video",
                             "Lo siento. No se ha podido abrir el video.");
        close();
    }
    Mat frame;
    vc >> frame;
    namedWindow("Frame actual", 0);
    imshow("Frame actual", frame);
    int cont = vc.get(CAP_PROP_FRAME_COUNT);
    ui->horizontalSlider->setMaximum(cont -1);
    ui->spinBox->setMaximum(cont -1);

}

AbrirVideo::~AbrirVideo()
{
    delete ui;
}

void AbrirVideo::on_horizontalSlider_valueChanged(int value)
{
    vc.set(CAP_PROP_POS_FRAMES, value);
    Mat frame;
    vc >> frame;
    namedWindow("Frame actual", 0);
    imshow("Frame actual", frame);
    ui->spinBox->setValue(value);
}

void AbrirVideo::on_spinBox_valueChanged(int arg1)
{
    ui->horizontalSlider->setValue(arg1);
}

void AbrirVideo::on_buttonBox_accepted()
{
    vc.set(CAP_PROP_POS_FRAMES, ui->spinBox->value());
    Mat frame;
    vc >> frame;

    crear_nueva(primera_libre(), frame);
    namedWindow("Frame actual", 0);
    destroyWindow("Frame actual");
    vc.release();
}

void AbrirVideo::on_buttonBox_rejected()
{
    namedWindow("Frame actual", 0);
    destroyWindow("Frame actual");
    vc.release();
}
