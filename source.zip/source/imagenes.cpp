//---------------------------------------------------------------------------

#include "imagenes.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include <QFileDialog>
#include <assert.h>

///////////////////////////////////////////////////////////////////
/////////  VARIABLES GLOBALES                        //////////////
///////////////////////////////////////////////////////////////////

ventana foto[MAX_VENTANAS];

tipo_herramienta herr_actual= HER_PUNTO;

int radio_pincel= 10;

Scalar color_pincel= CV_RGB(255, 255, 255);

int difum_pincel= 10;

bool preguntar_guardar= true;

static int numpos= 0; // Número actual en el orden de posición de las ventanas

// Para la herramienta TRAZO
Point punto_inicial;

///////////////////////////////////////////////////////////////////
/////////  FUNCIONES DE MANEJO DE VENTANAS           //////////////
///////////////////////////////////////////////////////////////////

void callback (int event, int x, int y, int flags, void *_nfoto);

void SetStatusBar1 (int masfotos);

//---------------------------------------------------------------------------

void inic_fotos (void)
{
    for (int i= 0; i<MAX_VENTANAS; i++)
        foto[i].usada= false;
}

//---------------------------------------------------------------------------

void fin_fotos (void)
{
    for (int i= 0; i<MAX_VENTANAS; i++) {
        if (foto[i].usada) {
            destroyWindow(foto[i].nombre);
            foto[i].usada= false;
        }
    }
}

//---------------------------------------------------------------------------

int primera_libre (void)
{
    for (int i= 0; i<MAX_VENTANAS; i++)
        if (!foto[i].usada)
            return i;
    return -1;
}

//---------------------------------------------------------------------------

void escribir_barra_estado (void)
{
    int usadas, modificadas;
    num_fotos(usadas, modificadas);
    w->setStatusBarText(QString::number(usadas)+" fotos abiertas, "+
                        QString::number(modificadas)+" modificadas.");
}

//---------------------------------------------------------------------------

void crear_nueva (int nfoto, int ancho, int alto, Scalar color)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && !foto[nfoto].usada);
    foto[nfoto].nombre= "nueva-"+to_string(nfoto)+".png";
    foto[nfoto].nombref= foto[nfoto].nombre;
    foto[nfoto].img.create(alto, ancho, CV_8UC3);
    foto[nfoto].img=  color;
    namedWindow(foto[nfoto].nombre, WINDOW_NO_POPUP+WINDOW_MOVE_RIGHT);
    foto[nfoto].orden= numpos++;
    imshow(foto[nfoto].nombre, foto[nfoto].img);
    foto[nfoto].usada= true;
    foto[nfoto].modificada= true;
    foto[nfoto].roi= Rect(0, 0, ancho, alto);
    setMouseCallback(foto[nfoto].nombre, callback, (void*) nfoto);
    escribir_barra_estado();
}

//---------------------------------------------------------------------------

void crear_nueva (int nfoto, Mat img)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && !foto[nfoto].usada && !img.empty());
    foto[nfoto].nombre= "nueva-"+to_string(nfoto)+".png";
    foto[nfoto].nombref= foto[nfoto].nombre;
    foto[nfoto].img= img;
    namedWindow(foto[nfoto].nombre, WINDOW_NO_POPUP+WINDOW_MOVE_RIGHT);
    foto[nfoto].orden= numpos++;
    imshow(foto[nfoto].nombre, foto[nfoto].img);
    foto[nfoto].usada= true;
    foto[nfoto].modificada= true;
    foto[nfoto].roi= Rect(0, 0, img.cols, img.rows);
    setMouseCallback(foto[nfoto].nombre, callback, (void*) nfoto);
    escribir_barra_estado();
}

//---------------------------------------------------------------------------

void crear_nueva (int nfoto, string nombre)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && !foto[nfoto].usada);
    foto[nfoto].nombre= nombre;
    foto[nfoto].nombref= Lt1(nombre);
    foto[nfoto].img= imread(foto[nfoto].nombref);
    if (foto[nfoto].img.empty())
        return;
    namedWindow(foto[nfoto].nombre, WINDOW_NO_POPUP+WINDOW_MOVE_RIGHT);
    foto[nfoto].orden= numpos++;
    imshow(foto[nfoto].nombre, foto[nfoto].img);
    foto[nfoto].usada= true;
    foto[nfoto].modificada= false;
    foto[nfoto].roi= Rect(0, 0, foto[nfoto].img.cols, foto[nfoto].img.rows);
    setMouseCallback(foto[nfoto].nombre, callback, (void*) nfoto);
    escribir_barra_estado();
}

//---------------------------------------------------------------------------

void guardar_foto (int nfoto, string nombre)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);
    foto[nfoto].modificada= false;
    // 1. Guardar la imagen con el mismo nombre que tiene
    if (nombre=="")
        imwrite(foto[nfoto].nombref, foto[nfoto].img);
    // 2. Guardar la imagen con un nombre distinto al actual
    else {
        imwrite(Lt1(nombre), foto[nfoto].img);
        setWindowTitle(foto[nfoto].nombre, nombre);
    }
    escribir_barra_estado();
}

//---------------------------------------------------------------------------

void cerrar_foto (int nfoto, bool destruir_ventana)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);
    if (destruir_ventana)
        destroyWindow(foto[nfoto].nombre);
    foto[nfoto].usada= false;
    escribir_barra_estado();
}

//---------------------------------------------------------------------------

void mostrar (int nfoto)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);
    imshow(foto[nfoto].nombre, foto[nfoto].img);
}

//---------------------------------------------------------------------------

int nombre_a_numero (string nombre)
{
    for (int i= 0; i<MAX_VENTANAS; i++)
        if (foto[i].usada && foto[i].nombre==nombre)
            return i;
    return -1;
}

//---------------------------------------------------------------------------

int foto_activa (void)
{
    int maxorden= -1, maxpos= -1;
    for (int i= 0; i<MAX_VENTANAS; i++) {
        if (foto[i].usada && foto[i].orden>maxorden) {
            maxorden= foto[i].orden;
            maxpos= i;
        }
    }
    return maxpos;
}

//---------------------------------------------------------------------------

int num_fotos (int &usadas, int &modificadas)
{
    usadas= 0;
    modificadas= 0;
    for (int i= 0; i<MAX_VENTANAS; i++) {
        if (foto[i].usada) {
            usadas++;
            if (foto[i].modificada)
                modificadas++;
        }
    }
    return usadas;
}


int set_callback(int nfoto)
{
    setMouseCallback(foto[nfoto].nombre, callback, (void*) nfoto);
}


///////////////////////////////////////////////////////////////////
/////////  FUNCIONES DEL CALLBACK PRINCIPAL          //////////////
///////////////////////////////////////////////////////////////////

static int downx, downy;
// Posición inicial del ratón al pinchar sobre la imagen actual

//---------------------------------------------------------------------------

void ninguna_accion (int factual, int x, int y)
{
    Mat res= foto[factual].img.clone();
    circle(res, Point(x, y), radio_pincel, CV_RGB(255,255,255), 2, LINE_AA);
    imshow(foto[factual].nombre, res);
}

//---------------------------------------------------------------------------

void cb_close (int factual)
{
    if (foto[factual].usada && !foto[factual].img.empty()) {
        if (foto[factual].modificada && preguntar_guardar) {
            QString cadena= "El archivo " + QString::fromStdString(foto[factual].nombre) +
                    " ha sido modificado.\n¿Desea guardarlo?";
            int resp= QMessageBox::question(w, "Archivo modificado", cadena,
                                            QMessageBox::Yes | QMessageBox::No );
            if (resp==QMessageBox::Yes)
                guardar_foto(factual);
        }
        cerrar_foto(factual, false);
    }
}

//---------------------------------------------------------------------------

void cb_punto (int factual, int x, int y)
{
    Mat im= foto[factual].img;  // Ojo: esto no es una copia, sino a la misma imagen
    if (difum_pincel==0)
        circle(im, Point(x, y), radio_pincel, color_pincel, -1, LINE_AA);
    else {
        int tam = radio_pincel + difum_pincel;
        Rect rroi(x-tam, y-tam, tam*2+1, tam*2+1);

        // Saturamos para que no de error si me salgo de la ventana
        int circlex = tam;
        int circley = tam;

        // Si se sale por la izquierda
        if (rroi.x < 0)
        {
            rroi.width += rroi.x;
            circlex += rroi.x;
            rroi.x =0;
        }

        // Si se sale por arriba
        if (rroi.y < 0)
        {
            rroi.height += rroi.y;
            circley += rroi.y;
            rroi.y =0;
        }

        // Si se sale por la derecha
        if (rroi.x + rroi.width > im.cols)
        {
            rroi.width = im.cols -  rroi.x;
        }

        // Si se sale por abajo
        if (rroi.y + rroi.height > im.rows)
        {
            rroi.height = im.rows -  rroi.y;
        }

        Mat roi = im(rroi);
        Mat res(roi.size(), im.type(), color_pincel);
        Mat cop(roi.size(), im.type(), CV_RGB(0,0,0));
        circle(cop, Point(circlex, circley), radio_pincel, CV_RGB(255,255,255), -1, LINE_AA);
        blur(cop, cop, Size(difum_pincel*2+1, difum_pincel*2+1));
        multiply(res, cop, res, 1.0/255.0);
        bitwise_not(cop, cop);
        multiply(roi, cop, roi, 1.0/255.0);
        roi= res + roi;
    }
    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;
}

//---------------------------------------------------------------------------

void cb_arcoiris (int factual, int x, int y)
{
    static int pos = 0;
    static unsigned char A[3][25] = {
                                    {255, 255, 255, 255, 255, 192, 128, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 128, 192, 255, 255, 255, 255, 255},
                                    {0, 64, 128, 192, 255, 255, 255, 255, 255, 255, 255, 255, 255, 192, 128, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                    {0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 128, 192, 255, 255, 255, 255, 255, 255, 255, 255, 255, 192, 128, 64, 0}};


    Mat im= foto[factual].img;  // Ojo: esto no es una copia, sino a la misma imagen
    if (difum_pincel==0)
        circle(im, Point(x, y), radio_pincel, CV_RGB(A[0][pos], A[1][pos], A[2][pos]), -1, LINE_AA);
    else {
        int tam = radio_pincel + difum_pincel;
        Rect rroi(x-tam, y-tam, tam*2+1, tam*2+1);

        // Saturamos para que no de error si me salgo de la ventana
        int circlex = tam;
        int circley = tam;

        // Si se sale por la izquierda
        if (rroi.x < 0)
        {
            rroi.width += rroi.x;
            circlex += rroi.x;
            rroi.x =0;
        }

        // Si se sale por arriba
        if (rroi.y < 0)
        {
            rroi.height += rroi.y;
            circley += rroi.y;
            rroi.y =0;
        }

        // Si se sale por la derecha
        if (rroi.x + rroi.width > im.cols)
        {
            rroi.width = im.cols -  rroi.x;
        }

        // Si se sale por abajo
        if (rroi.y + rroi.height > im.rows)
        {
            rroi.height = im.rows -  rroi.y;
        }

        Mat roi = im(rroi);
        Mat res(roi.size(), im.type(),  CV_RGB(A[0][pos], A[1][pos], A[2][pos]));
        Mat cop(roi.size(), im.type(), CV_RGB(0,0,0));
        circle(cop, Point(circlex, circley), radio_pincel, CV_RGB(255,255,255), -1, LINE_AA);
        blur(cop, cop, Size(difum_pincel*2+1, difum_pincel*2+1));
        multiply(res, cop, res, 1.0/255.0);
        bitwise_not(cop, cop);
        multiply(roi, cop, roi, 1.0/255.0);
        roi= res + roi;
    }

    pos = (pos+1)%24;
    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;

}

//---------------------------------------------------------------------------


void cb_rellenar (int factual, int x, int y)
{
    Mat img = foto[factual].img;
    Mat rellenado = img.clone();
    int flags = 4 | FLOODFILL_FIXED_RANGE | (255 << 8);

    // Establecemos los parámetros necesarios para ajustar la tolerancia de rellenado
    int lo = radio_pincel;
    int up = radio_pincel;

    floodFill(rellenado, Point(x, y), color_pincel, nullptr, Scalar(lo, lo, lo), Scalar(up, up, up), flags); // solo acepta una imagen de 1 o 3 canales con 8 bit

    // Vamos a utilizar la media ponderada para establecer la transparencia del rellenado
    // como el difuminado se estableció inicialmente hasta 120, vamos a saturarlo en 100

    double transparencia;
    if (difum_pincel > 100)
        transparencia = 1.0;
    else
        transparencia = difum_pincel/100.0;

    addWeighted(img, transparencia, rellenado, 1.0-transparencia, 0, img);

    imshow(foto[factual].nombre, img);
    foto[factual].modificada= true;

}


//---------------------------------------------------------------------------

void cb_suavizar (int factual, int x, int y)
{
    Mat im= foto[factual].img;

    int tam = radio_pincel;
    Rect rroi(x-tam, y-tam, tam*2+1, tam*2+1);

    // Si se sale por la izquierda
    if (rroi.x < 0)
    {
        rroi.width += rroi.x;
        rroi.x =0;
    }
    // Si se sale por arriba
    if (rroi.y < 0)
    {
        rroi.height += rroi.y;
        rroi.y =0;
    }
    // Si se sale por la derecha
    if (rroi.x + rroi.width > im.cols)
    {
        rroi.width = im.cols -  rroi.x;
    }
    // Si se sale por abajo
    if (rroi.y + rroi.height > im.rows)
    {
        rroi.height = im.rows -  rroi.y;
    }

    Mat roi = im(rroi);
    GaussianBlur(roi, roi, Size(difum_pincel*2+1, difum_pincel*2+1), 0);

    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;
}

//---------------------------------------------------------------------------

void cb_linea (int factual, int x, int y)
{
    Mat im= foto[factual].img;  // Ojo: esto no es una copia, sino a la misma imagen
    if (difum_pincel==0)
        line(im, Point(downx, downy), Point(x,y), color_pincel, radio_pincel*2+1);
    else {
        Mat res(im.size(), im.type(), color_pincel);
        Mat cop(im.size(), im.type(), CV_RGB(0,0,0));
        line(cop, Point(downx, downy), Point(x,y), CV_RGB(255,255,255), radio_pincel*2+1);
        blur(cop, cop, Size(difum_pincel*2+1, difum_pincel*2+1));
        multiply(res, cop, res, 1.0/255.0);
        bitwise_not(cop, cop);
        multiply(im, cop, im, 1.0/255.0);
        im= res + im;
    }
    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;
}

void cb_ver_linea (int factual, int x, int y)
{
    Mat res= foto[factual].img.clone();
    line(res, Point(downx, downy), Point(x,y), color_pincel, radio_pincel*2+1);
    imshow(foto[factual].nombre, res);
}

//---------------------------------------------------------------------------

void cb_trazo (int factual, int x, int y)
{
    // Es la misma función que línea pero se ha cambiado el punto de inicio de la línea

    Mat im= foto[factual].img;
    if (difum_pincel==0)
        line(im, punto_inicial, Point(x,y), color_pincel, radio_pincel*2+1);
    else {
        Mat res(im.size(), im.type(), color_pincel);
        Mat cop(im.size(), im.type(), CV_RGB(0,0,0));
        line(cop, punto_inicial, Point(x,y), CV_RGB(255,255,255), radio_pincel*2+1);
        blur(cop, cop, Size(difum_pincel*2+1, difum_pincel*2+1));
        multiply(res, cop, res, 1.0/255.0);
        bitwise_not(cop, cop);
        multiply(im, cop, im, 1.0/255.0);
        im= res + im;
    }
    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;
}

//---------------------------------------------------------------------------

void cb_rectangulo (int factual, int x, int y)
{
    Mat im= foto[factual].img;  // Ojo: esto no es una copia, sino a la misma imagen
    if (difum_pincel==0)
        rectangle(im, Point(downx, downy), Point(x,y), color_pincel, radio_pincel*2-1);
    else {
        Mat res(im.size(), im.type(), color_pincel);
        Mat cop(im.size(), im.type(), CV_RGB(0,0,0));
        rectangle(cop, Point(downx, downy), Point(x,y), CV_RGB(255,255,255), radio_pincel*2-1);
        blur(cop, cop, Size(difum_pincel*2+1, difum_pincel*2+1));
        multiply(res, cop, res, 1.0/255.0);
        bitwise_not(cop, cop);
        multiply(im, cop, im, 1.0/255.0);
        im= res + im;
    }
    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;
}


void cb_ver_rectangulo (int factual, int x, int y)
{
    Mat res= foto[factual].img.clone();
    rectangle(res, Point(downx, downy), Point(x,y), color_pincel, radio_pincel*2+1);
    imshow(foto[factual].nombre, res);
}

//---------------------------------------------------------------------------

void cb_elipse (int factual, int x, int y)
{
    Mat im= foto[factual].img;  // Ojo: esto no es una copia, sino a la misma imagen
    if (difum_pincel==0)
        ellipse(im, Point(downx, downy), Size( abs(x-downx), abs(y-downy)), 0, 0, 360, color_pincel, radio_pincel-1, LINE_AA);
    else {
        Mat res(im.size(), im.type(), color_pincel);
        Mat cop(im.size(), im.type(), CV_RGB(0,0,0));
        ellipse(cop, Point(downx, downy), Size( abs(x-downx), abs(y-downy)), 0, 0, 360,  CV_RGB(255,255,255), radio_pincel-1, LINE_AA);
        blur(cop, cop, Size(difum_pincel*2+1, difum_pincel*2+1));
        multiply(res, cop, res, 1.0/255.0);
        bitwise_not(cop, cop);
        multiply(im, cop, im, 1.0/255.0);
        im= res + im;
    }
    imshow(foto[factual].nombre, im);
    foto[factual].modificada= true;
}


void cb_ver_elipse (int factual, int x, int y)
{
    Mat res= foto[factual].img.clone();
    ellipse(res, Point(downx, downy), Size( abs(x-downx), abs(y-downy)), 0, 0, 360, color_pincel, radio_pincel-1, LINE_AA);
    imshow(foto[factual].nombre, res);
}

//---------------------------------------------------------------------------

void cb_seleccionar (int factual, int x, int y)
{
    Mat im= foto[factual].img;
    Rect nuevo= Rect(min(downx, x), min(downy, y),
                     max(downx, x)-min(downx, x)+1, max(downy, y)-min(downy, y)+1);
    if (nuevo.x<0)
        nuevo.x= 0;
    if (nuevo.y<0)
        nuevo.y= 0;
    if (nuevo.x+nuevo.width>im.size().width)
        nuevo.width= im.size().width-nuevo.x;
    if (nuevo.y+nuevo.height>im.size().height)
        nuevo.height= im.size().height-nuevo.y;
    foto[factual].roi= nuevo;
}


void cb_ver_seleccion (int factual, int x, int y, bool foto_roi)
{
    Mat res= foto[factual].img.clone();
    Point p1, p2;
    if (foto_roi) {
        p1.x= foto[factual].roi.x;
        p1.y= foto[factual].roi.y;
        p2.x= foto[factual].roi.x+foto[factual].roi.width-1;
        p2.y= foto[factual].roi.y+foto[factual].roi.height-1;
    }
    else {
        p1= Point(downx, downy);
        p2= Point(x, y);
    }
    rectangle(res, p1, p2, CV_RGB(255,foto_roi?0:255,0),2);
    imshow(foto[factual].nombre, res);
}

//---------------------------------------------------------------------------

void callback (int event, int x, int y, int flags, void *_nfoto)
{
    int factual= (int) _nfoto;

    // 1. Eventos y casos especiales
    // 1.1. Evento cerrar ventana
    if (event==EVENT_CLOSE) {
        cb_close(factual);
        return;
    }
    // 1.2. Evento obtiene el foco
    if (event==EVENT_FOCUS) {
        foto[factual].orden= numpos++;
    }
    // 1.3. El ratón se sale de la ventana
    if (x<0 || x>=foto[factual].img.size().width || y<0 || y>=foto[factual].img.size().height)
        return;
    // 1.4. Se inicia la pulsación del ratón
    if (event==EVENT_LBUTTONDOWN) {
        downx= x;
        downy= y;
    }

    // 2. Según la herramienta actual
    switch (herr_actual) {

    // 2.1. Herramienta PUNTO
    case HER_PUNTO:
        if (flags==EVENT_FLAG_LBUTTON)
            cb_punto(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;

        // 2.2. Herramienta LINEA
    case HER_LINEA:
        if (event==EVENT_LBUTTONUP)
            cb_linea(factual, x, y);
        else if (event==EVENT_MOUSEMOVE && flags==EVENT_FLAG_LBUTTON)
            cb_ver_linea(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;

        // 2.3. Herramienta SELECCION
    case HER_SELECCION:
        if (event==EVENT_LBUTTONUP)
            cb_seleccionar(factual, x, y);
        else if (event==EVENT_MOUSEMOVE)
            cb_ver_seleccion(factual, x, y, flags!=EVENT_FLAG_LBUTTON);
        break;

    // 2.4. Herramienta RECTANGULO
    case HER_RECTANGULO:
        if (event==EVENT_LBUTTONUP)
            cb_rectangulo(factual, x, y);
        else if (event==EVENT_MOUSEMOVE && flags==EVENT_FLAG_LBUTTON)
            cb_ver_rectangulo(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;

    // 2.5. Herramienta ELIPSE
    case HER_ELIPSE:
        if (event==EVENT_LBUTTONUP)
            cb_elipse(factual, x, y);
        else if (event==EVENT_MOUSEMOVE && flags==EVENT_FLAG_LBUTTON)
            cb_ver_elipse(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;

    // 2.6. Herramienta ARCOIRIS
    case HER_ARCOIRIS:
        if (flags==EVENT_FLAG_LBUTTON)
            cb_arcoiris(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;

    // 2.7. Herramienta RELLENAR
    case HER_RELLENAR:
        if (flags==EVENT_FLAG_LBUTTON)
            cb_rellenar(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;

    // 2.8. Herramienta SUAVIZAR
    case HER_SUAVIZAR:
        if (flags==EVENT_FLAG_LBUTTON)
            cb_suavizar(factual, x, y);
        else
            ninguna_accion(factual, x, y);
        break;


    // 2.9. Herramienta TRAZO
    case HER_TRAZO:
        // Con el primer click establecemos el punto inicial
        if (event == EVENT_LBUTTONDOWN)
            punto_inicial = Point(x, y);
        else if (event==EVENT_MOUSEMOVE && flags==EVENT_FLAG_LBUTTON){
                cb_trazo(factual, x, y); // Se dibuja una línea desde punto_inicial hasta el punto actual (x, y)
                punto_inicial = Point(x, y); // se actualiza el punto al anterior
        }else
            ninguna_accion(factual, x, y);

        break;
    }

}


///////////////////////////////////////////////////////////////////
/////////  FUNCIONES DE PROCESAMIENTO DE IMAGENES    //////////////
///////////////////////////////////////////////////////////////////

void invertir (int nfoto, int nres)
{
    Mat img(foto[nfoto].img.size(), foto[nfoto].img.type());
    bitwise_not(foto[nfoto].img, img);
    crear_nueva(nres, img);
}

//---------------------------------------------------------------------------

void rotar_angulo (int nfoto, Mat &imgRes, double angulo, double escala, int modo)
{
    Mat imagen= foto[nfoto].img;
    double w= imagen.size().width, h= imagen.size().height;
    Size sres;
    if (modo==0) {     // Reescalar con proporción al original
        sres.width= int(w*escala);
        sres.height= int(h*escala);
    }
    else if (modo==1)  // Reescalar y ampliar para caber entera
        sres.width= sres.height= int(sqrt(w*w + h*h)*escala);
    else               // Reescalar y recortar para no mostrar borde
        sres.width= sres.height= int(min(w, h)*escala/sqrt(2.0));
    imgRes.create(sres, imagen.type());
    double sa= sin(angulo*M_PI/180), ca= cos(angulo*M_PI/180);
    double cx= -w/2*ca-h/2*sa, cy= w/2*sa-h/2*ca;
    Mat M= getRotationMatrix2D(Point2f(0,0), angulo, escala);
    M.at<double>(0,2)= sres.width/2+cx*escala;
    M.at<double>(1,2)= sres.height/2+cy*escala;
    imgRes= color_pincel;
    warpAffine(imagen, imgRes, M, sres);
}

void rotar_angulo (Mat imagen, Mat &imgRes, double angulo, double escala, int modo)
{
    double w= imagen.size().width, h= imagen.size().height;
    Size sres;
    if (modo==0) {     // Reescalar con proporción al original
        sres.width= int(w*escala);
        sres.height= int(h*escala);
    }
    else if (modo==1)  // Reescalar y ampliar para caber entera
        sres.width= sres.height= int(sqrt(w*w + h*h)*escala);
    else               // Reescalar y recortar para no mostrar borde
        sres.width= sres.height= int(min(w, h)*escala/sqrt(2.0));
    imgRes.create(sres, imagen.type());
    double sa= sin(angulo*M_PI/180), ca= cos(angulo*M_PI/180);
    double cx= -w/2*ca-h/2*sa, cy= w/2*sa-h/2*ca;
    Mat M= getRotationMatrix2D(Point2f(0,0), angulo, escala);
    M.at<double>(0,2)= sres.width/2+cx*escala;
    M.at<double>(1,2)= sres.height/2+cy*escala;
    imgRes= color_pincel;
    warpAffine(imagen, imgRes, M, sres);
}
//---------------------------------------------------------------------------

void rotar_exacto (int nfoto, int nres, int grado)
{
    Mat entrada= foto[nfoto].img;
    Mat salida;
    if (grado==0)
        salida= entrada.clone();
    else if (grado==1) {
        transpose(entrada, salida);
        flip(salida, salida, 1);
    }
    else if (grado==2)
        flip(entrada, salida, -1);
    else if (grado==3) {
        transpose(entrada, salida);
        flip(salida, salida, 0);
    }
    crear_nueva(nres, salida);
}

//---------------------------------------------------------------------------

void ver_brillo_contraste_gama (int nfoto, double suma, double prod, double gama, bool guardar)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);
    Mat img;
    foto[nfoto].img.convertTo(img, CV_8UC3, prod, suma);

    Mat img32f;
    img.convertTo(img32f, CV_32FC3, 1.0/255); // convertimos la imagen a 32f y la dividimos por 255 para calcular la gama
    pow(img32f, gama, img);
    img.convertTo(img, CV_8UC3, 255); // volvemos a la imagen original

    imshow(foto[nfoto].nombre, img);
    if (guardar) {
        img.copyTo(foto[nfoto].img);
        foto[nfoto].modificada= true;
    }
    else
        ver_histograma(img);

}


//---------------------------------------------------------------------------

void ver_suavizado (int nfoto, int ntipo, int tamx, int tamy, bool guardar)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);

    Mat img= foto[nfoto].img.clone();
    Mat roi = img(foto[nfoto].roi);

    if (ntipo==1)
        GaussianBlur(roi, roi, Size(tamx, tamy), 0);
    else if (ntipo==2)
        blur(roi, roi, Size(tamx, tamy));
    else if (ntipo==3)
        medianBlur(roi, roi, tamx > 360? 361 : tamx);

    imshow(foto[nfoto].nombre, img);
    if (guardar) {
        img.copyTo(foto[nfoto].img);
        foto[nfoto].modificada= true;
    }
}

//---------------------------------------------------------------------------

void ver_perfilado (int nfoto, int radio, double porcentaje, bool guardar)
{

    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);

    Mat img_original, img_original_16S, laplace, resultado;

    img_original = foto[nfoto].img.clone();
    img_original = img_original(foto[nfoto].roi);

    // Convertimos a 16S
    img_original.convertTo(img_original_16S, CV_16S);
    // Aplicamos la laplaciana a la imagen original
    Laplacian(img_original, laplace, CV_16S, radio);
    // Multiplicamos la laplaciana por el porcentaje
    porcentaje = porcentaje/100.0;
    laplace *= porcentaje;
    // Se suma la laplaciana a la imagen original de 16S
    resultado = img_original_16S - laplace;
    // Convertimos a 8U
    resultado.convertTo(resultado, CV_8U);

    imshow(foto[nfoto].nombre, resultado);

    if (guardar) {
        resultado.copyTo(foto[nfoto].img);
        foto[nfoto].modificada= true;
    }

}


//---------------------------------------------------------------------------

void ver_colorfalso(int nfoto, int nres, int map)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);

    // Primero convertimos la imagen a escala de grises
    Mat img_gray, img_res;
    cvtColor(foto[nfoto].img, img_gray, COLOR_BGR2GRAY);

    // Aplicamos el mapa de color
    applyColorMap(img_gray, img_res, map);

    // Mostramos la transformación
    crear_nueva(nres, img_res);

}

//---------------------------------------------------------------------------

void media_ponderada (int nf1, int nf2, int nueva, double peso)
{
    Mat img= foto[nf1].img.clone();
    Mat cop;
    resize(foto[nf2].img, cop, img.size());
    addWeighted(img, peso, cop, 1.0-peso, 0, img);
    crear_nueva(nueva, img);
}

//---------------------------------------------------------------------------

void histograma (int nfoto, int nres, int tipo)
{
    QImage imq= QImage(":/new/prefix1/imagenes/histbase.png");
    Mat img(imq.height(),imq.width(),CV_8UC4,imq.scanLine(0));
    cvtColor(img, img, COLOR_RGBA2RGB);

    Mat gris;
    Mat hist;

    if (tipo == 3)
        cvtColor(foto[nfoto].img, gris, COLOR_BGR2GRAY);  // Conversión a gris
    int canales[1]= {0};
    int bins[1]= {256};
    float rango[2]= {0, 256};
    const float *rangos[]= {rango};

    if (tipo == 3)
        calcHist(&gris, 1, canales, noArray(), hist, 1, bins, rangos);
    else {
        canales[0] = tipo;
        calcHist(&foto[nfoto].img, 1, canales, noArray(), hist, 1, bins, rangos);
    }

    double min, max;
    minMaxLoc(hist, &min, &max);

    // Pintamos los rectangulos del histograma
    for (int i= 0; i<256; i++)
        rectangle(img, Point(3+i*391/256,185), Point(3+(i+1)*391/256, 185-hist.at<float>(i)/max*182), CV_RGB(tipo==2?255:0,tipo==1?255:0,tipo==0?255:0), -1); // Ha sido necesario escalarlo a la imagen de fondo (histbase.png)


    crear_nueva(nres, img);
}

//---------------------------------------------------------------------------

void ver_histograma (Mat img2)
{
    QImage imq= QImage(":/new/prefix1/imagenes/histbase.png");
    Mat img(imq.height(),imq.width(),CV_8UC4,imq.scanLine(0));
    cvtColor(img, img, COLOR_RGBA2RGB);

    Mat gris;
    Mat hist;

    cvtColor(img2, gris, COLOR_BGR2GRAY);  // Conversión a gris

    int canales[1]= {0};
    int bins[1]= {256};
    float rango[2]= {0, 256};
    const float *rangos[]= {rango};

    calcHist(&gris, 1, canales, noArray(), hist, 1, bins, rangos);

    double min, max;
    minMaxLoc(hist, &min, &max);

    // Pintamos los rectangulos del histograma
    for (int i= 0; i<256; i++)
        rectangle(img, Point(3+i*391/256,185), Point(3+(i+1)*391/256, 185-hist.at<float>(i)/max*182), CV_RGB(0,0,0), -1); // Ha sido necesario escalarlo a la imagen de fondo (histbase.png)


    namedWindow("Histograma", WINDOW_NORMAL);
    imshow("Histograma", img);
}


//---------------------------------------------------------------------------

string Lt1(string cadena)
{
    QString temp= QString::fromUtf8(cadena.c_str());
    return temp.toLatin1().data();
}

//---------------------------------------------------------------------------


void ver_pinchar (int nfoto, Point centro, double grado, double tam, bool guardar)
{
    assert(nfoto>=0 && nfoto<MAX_VENTANAS && foto[nfoto].usada);
    Mat img= foto[nfoto].img.clone();

    double sigma = 1.0/(tam*tam);
    Mat S(img.size(), CV_32FC1);
    for (int y = 0; y < img.rows; y++) {
        for (int x = 0; x < img.cols; x++) {
            double dist = (x - centro.x)*(x - centro.x)+ (y - centro.y)*(y - centro.y);
            S.at<float> (y,x) = exp(-dist*sigma);
        }
    }

    Mat Sx, Sy;
    Sobel(S, Sx, CV_32F, 1, 0);
    Sobel(S, Sy, CV_32F, 0, 1);

    multiply(S, Sx, Sx, grado*tam*tam);
    multiply(S, Sy, Sy, grado*tam*tam);

    Mat MapaX(1, img.cols, CV_32FC1);
    for (int x = 0; x < img.cols; ++x)
        MapaX.at<float>(0,x) = x;
    resize(MapaX, MapaX, img.size());

    Mat MapaY(img.rows, 1, CV_32FC1);
    for (int y = 0; y < img.rows; ++y)
        MapaY.at<float>(y,0) = y;
    resize(MapaY, MapaY, img.size());

    MapaX = MapaX+Sx;
    MapaY = MapaY+Sy;

    remap(foto[nfoto].img, img, MapaX, MapaY, INTER_LINEAR, BORDER_REFLECT);

    imshow(foto[nfoto].nombre, img);
    if (guardar) {
        img.copyTo(foto[nfoto].img);
        foto[nfoto].modificada= true;
    }
}

//---------------------------------------------------------------------------


void ver_matiz_sat_lum(int nfoto, int matiz, double sat, double lum, bool guardar)
{
    Mat img = foto[nfoto].img.clone();
    Mat hls;
    cvtColor(img, hls, COLOR_BGR2HLS_FULL);

    vector<Mat> canales;
    split(hls, canales);

    Mat i16;
    canales[0].convertTo(i16, CV_16S);
    i16 += matiz;
    bitwise_and(i16, 255, i16);
    i16.convertTo(canales[0], CV_8U);


    canales[1] *= lum;
    canales[2] *= sat;

    merge(canales, hls);

    cvtColor(hls, img, COLOR_HLS2BGR_FULL);

    imshow(foto[nfoto].nombre, img);
    if (guardar)
    {
        img.copyTo(foto[nfoto].img);
        foto[nfoto].modificada = true;
    }

}

//---------------------------------------------------------------------------

void balance_de_blancos(int nfoto, int nres)
{
    Mat yuv;
    cvtColor(foto[nfoto].img, yuv, COLOR_BGR2YUV);
    Scalar media = mean(yuv); // matriz de cuatro colores
    Scalar suma(0, 128-media.val[1], 128 - media.val[2]);
    yuv += suma;
    Mat res;
    cvtColor(yuv, res, COLOR_YUV2BGR);
    crear_nueva(nres, res);
}

//---------------------------------------------------------------------------

void escala_color(int nfoto, int nres, Scalar color)
{

    int media = 0.21 * color.val[2] + 0.72 * color.val[1] + 0.07 * color.val[0];

    if (media == 0)
        media = 1; //para evitar división por 0
    if (media == 255)
        media = 254; //para evitar división por 0

    Mat gris;
    cvtColor(foto[nfoto].img, gris, COLOR_BGR2GRAY);

    Mat lut(1, 256, CV_8UC3);
    for (int i=0; i < 256; i++)
    {
        if (i < media)
            lut.at<Vec3b> (0,i) = Vec3b(i*color.val[0]/media,
                                        i*color.val[1]/media,
                                        i*color.val[2]/media);
        else
            lut.at<Vec3b> (0,i) = Vec3b(color.val[0]+(255-color.val[0])*(i-media)/(255-media),
                                        color.val[1]+(255-color.val[1])*(i-media)/(255-media),
                                        color.val[2]+(255-color.val[2])*(i-media)/(255-media));
    }

    cvtColor(gris, gris, COLOR_GRAY2BGR);
    Mat res;
    LUT(gris, lut, res);

    crear_nueva(nres, res);

}

//---------------------------------------------------------------------------

void ver_ajuste_lineal(int nfoto, double pmin, double pmax, bool guardar)
{
    Mat gris;
    cvtColor(foto[nfoto].img, gris, COLOR_BGR2GRAY);

    Mat hist;

    int canales[1]= {0};
    int bins[1]= {256};
    float rango[2]= {0, 256};
    const float *rangos[]= {rango};
    calcHist(&gris, 1, canales, noArray(), hist, 1, bins, rangos);

    normalize(hist, hist, 100, 0, NORM_L1); // NORM_L1 es la suma

    double acum = 0;

    int m = 0;
    while (m < 255 && acum < pmin) {
        acum += hist.at<float>(m);
        m++;
    }

    int M = 255;
    acum = 0;
    while (M > 0 && acum < pmax) {
        acum += hist.at<float>(M);
        M--;
    }

    Mat res;
    foto[nfoto].img.convertTo(res, CV_8UC3, 255.0/(M-m), -m*255.0/(M-m));
    imshow(foto[nfoto].nombre, res);
    if (guardar) {
        res.copyTo(foto[nfoto].img);
        foto[nfoto].modificada=true;
    }
}

//---------------------------------------------------------------------------

void ver_perspectiva(int nfoto1, int nfoto2, Point2f p1[4], Point2f p2[4], bool guardar)
{

    //p2 contendrá la perspectiva, el resultado de transformar p1

    Mat M;
    M = getPerspectiveTransform(p1, p2);
    Mat img = foto[nfoto2].img.clone();
    warpPerspective(foto[nfoto1].img, img, M, img.size(), INTER_CUBIC, BORDER_TRANSPARENT);
    if (guardar)
    {
        img.copyTo(foto[nfoto2].img);
        foto[nfoto2].modificada = true;
    }
    else
    {
        namedWindow("Perspectiva", 0);
        imshow("Perspectiva", img);
    }
}

//---------------------------------------------------------------------------

void ver_bajorrelieve(int nfoto, int nres, double angulo, double grado, bool guardar)
{
    Mat gris, sobel16, sobel8, rotada;
    cvtColor(foto[nfoto].img, gris, COLOR_BGR2GRAY);

    rotar_angulo(gris, rotada, angulo, 1, 1);

    Sobel(rotada, sobel16, CV_16S, 1, 0, 3, grado);
    sobel16.convertTo(sobel8, CV_8U, 1, 128);

    rotar_angulo(sobel8, rotada, -angulo, 1, 0); //ya no es necesario ampliarlo
    int h = gris.rows;
    int w = gris.cols;
    int H = rotada.rows;
    int W = rotada.cols;
    sobel8 = rotada(Rect(W/2-w/2, H/2-h/2, w, h));

    cvtColor(sobel8, gris, COLOR_GRAY2BGR);

    if (guardar)
       crear_nueva(nres, gris);
    else {
       namedWindow("Bajorrelieve", 0);
       imshow("Bajorrelieve", gris);
    }

}

//---------------------------------------------------------------------------

Mat generar_texto(QString texto, Scalar color)
{
    QStringList lineas = texto.split('\n');
    Mat res(800 + 40 * lineas.size(), 600, CV_8UC3, CV_RGB(0,0,0));
    for (int i = 0; i < lineas.size(); i++)
    {
        putText(res, lineas[i].toLatin1().data(), Point(0, 440+40*i), FONT_HERSHEY_DUPLEX, 1 , color, 2, LINE_AA);
    }
    return res;
}

//---------------------------------------------------------------------------

void ver_texto(int nfoto, QString cadena, Point posicion, int tam, Scalar color_texto, bool sombrear, Scalar color_sombra, double transparencia, bool guardar)
{
    Mat im = foto[nfoto].img.clone();

    if (sombrear)
    {
        Mat res(im.size(), im.type(), color_sombra);
        imshow("1", res);
        Mat cop(im.size(), im.type(), CV_RGB(0,0,0));
        imshow("2", cop);

        putText(cop, cadena.toLatin1().data(), Point(posicion.x, posicion.y + 2), FONT_HERSHEY_DUPLEX, tam , CV_RGB(255,255,255), 2, LINE_AA);
        imshow("3", cop);

        blur(cop, cop, Size(5, 5));
        imshow("4", cop);

        addWeighted(cop, transparencia, res, 1.0 - transparencia, 0, res);
        imshow("5", res);

        multiply(res, cop, res, 1.0/255.0);
        imshow("6", res);
        bitwise_not(cop, cop);
        imshow("7", cop);
        multiply(im, cop, im, 1.0/255.0);
        imshow("8", im);
        im= res + im;
        imshow("9", im);

    }

    putText(im, cadena.toLatin1().data(), posicion, FONT_HERSHEY_DUPLEX, tam , color_texto, 2, LINE_AA);

    imshow(foto[nfoto].nombre, im);
    if (guardar) {
        im.copyTo(foto[nfoto].img);
        foto[nfoto].modificada= true;
    }
}
