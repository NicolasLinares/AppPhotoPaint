#include "perspectiva.h"
#include "ui_perspectiva.h"

void callback4 (int event, int x, int y, int flags, void *_pp)
{
    perspectiva *pp = (perspectiva *) _pp;
    if (flags == EVENT_FLAG_LBUTTON)
    {
        int posmin = -1;
        int distmin = 300;

        for (int i = 0; i < 4; i++)
        {
            int dist = abs(x - pp->p2[i].x) + abs(y - pp->p2[i].y);
            if (dist < distmin)
            {
                distmin = dist;
                posmin = i;
            }
        }

        if (posmin != -1)
        {
            pp->p2[posmin].x = x;
            pp->p2[posmin].y = y;
            ver_perspectiva(pp->nfoto1, pp->nfoto2, pp->p1, pp->p2);
        }

    }
}

perspectiva::perspectiva(int nfoto, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::perspectiva)
{
    ui->setupUi(this);

    nfoto1 = nfoto;

    for (int i= 0, pos= 0; i<MAX_VENTANAS; i++) {
        if (foto[i].usada) {
            ui->listWidget->addItem(QString::fromStdString(foto[i].nombre));
            corresp[pos++]= i;
        }
    }

    nfoto2 = corresp[0];
    p1[0] = Point2f(0,0);
    p1[1] = Point2f(foto[nfoto1].img.cols,0);
    p1[2] = Point2f(foto[nfoto1].img.cols, foto[nfoto1].img.rows);
    p1[3] = Point2f(0, foto[nfoto1].img.rows);

    p2[0] = Point2f(50,50);
    p2[1] = Point2f(foto[nfoto2].img.cols,0);
    p2[2] = Point2f(foto[nfoto2].img.cols, foto[nfoto2].img.rows);
    p2[3] = Point2f(0, foto[nfoto2].img.rows);

    ver_perspectiva(nfoto1, nfoto2, p1, p2);
    setMouseCallback("Perspectiva", callback4, this);
}

perspectiva::~perspectiva()
{
    delete ui;
}

void perspectiva::on_listWidget_currentRowChanged(int currentRow)
{
    nfoto2 = corresp[currentRow];
    ver_perspectiva(nfoto1, nfoto2, p1, p2);
    setMouseCallback("Perspectiva", callback4, this);

}

void perspectiva::on_perspectiva_rejected()
{
    destroyWindow("Perspectiva");
}

void perspectiva::on_perspectiva_accepted()
{
    ver_perspectiva(nfoto1, nfoto2, p1, p2, true);
    destroyWindow("Perspectiva");
    mostrar(nfoto2);
}
