#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QColorDialog>
#include <QMessageBox>
#include <opencv2/opencv.hpp>
using namespace cv;

#include "starwars.h"
#include "bajorrelieve.h"
#include "texto.h"
#include "colorfalso.h"
#include "acercade.h"
#include "brillocontrastegama.h"
#include "dialognueva.h"
#include "imagenes.h"
#include "mediadevideo.h"
#include "mediaponderada.h"
#include "rotaravideo.h"
#include "suavizados.h"
#include "pinchar.h"
#include "perfilado.h"
#include "copiarconefecto.h"
#include "matizsat.h"
#include "abrirvideo.h"
#include "video.h"
#include "ajustelineal.h"
#include "perspectiva.h"
#include <QClipboard>
#include <QMimeData>
#include <QPixmap>

QString FiltroImagen = "Todos los formatos (*.jpg *.jpeg *.jpe .jp2 *.tif *.tiff *.png *.gif *.bmp *.dib *.webp *.ppm);;Archivos JPG (*.jpg *.jpeg *.jpe);;Archivos TIF (*.tif *.tiff);;Archivos PNG (*.png);;Archivos GIF (*.gif);;Archivos BMP (*.bmp *.dib);;Otros (*.*)";

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::show()
{
    QMainWindow::show();
    move(x(), 0);
}

void MainWindow::setStatusBarText(QString cadena)
{
    ui->statusBar->showMessage(cadena, 0);
}

int MainWindow::comprobar_primera_libre (void)
{
    int pl= primera_libre();
    if (pl==-1)
        QMessageBox::warning(this, "Error al crear imagen",
                             "Lo siento. No se pueden crear más ventanas.");
    return pl;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}


void MainWindow::on_actionSalir_triggered()
{

    // Se ha reutilizado el código de la función cerrar para poder preguntar si guardar todas las imágenes que se encuentran abiertas antes de salir del programa

    int fa;
    while ((fa = foto_activa())!=-1) {
        if (foto[fa].modificada && preguntar_guardar) {
            QString nombre= QString::fromStdString(foto[fa].nombre);
            nombre= "El archivo " + nombre + " ha sido modificado.\n¿Desea guardarlo?";
            int resp= QMessageBox::question(this, "Archivo modificado", nombre,
                                            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
            if (resp==QMessageBox::Yes)
                guardar_foto(fa);
            else if (resp==QMessageBox::Cancel)
                return;
            else
                foto[fa].modificada= false;
        }
        cerrar_foto(fa);
    }

    close();
}

void MainWindow::on_actionNueva_imagen_triggered()
{
    int pl= comprobar_primera_libre();
    if (pl!=-1) {
        DialogNueva nueva;
        if (nueva.exec()) {
            Scalar color= CV_RGB(nueva.red(), nueva.green(), nueva.blue());
            crear_nueva(pl, nueva.getWidth(), nueva.getHeight(), color);
        }
    }
}

void MainWindow::on_actionAbrir_imagen_triggered()
{
    int pl= comprobar_primera_libre();
    if (pl!=-1) {
        QString nombre= QFileDialog::getOpenFileName(this, "Abrir imagen", ".", FiltroImagen);
        if (!nombre.isEmpty())
            crear_nueva(pl, nombre.toUtf8().data());
    }
}

void MainWindow::on_actionPunto_triggered()
{
    herr_actual= HER_PUNTO;
    ui->toolButton_4->setChecked(true);
}

void MainWindow::on_actionLinea_triggered()
{
    herr_actual= HER_LINEA;
    ui->toolButton_5->setChecked(true);
}

void MainWindow::on_actionSeleccionar_triggered()
{
    herr_actual= HER_SELECCION;
    ui->toolButton_6->setChecked(true);
}

void MainWindow::on_actionRectangulo_triggered()
{
    herr_actual = HER_RECTANGULO;
    ui->toolButton_7->setChecked(true);
}

void MainWindow::on_actionElipse_triggered()
{
    herr_actual = HER_ELIPSE;
    ui->toolButton_8->setChecked(true);
}


void MainWindow::on_toolButton_2_clicked()
{
    on_actionNueva_imagen_triggered();
}

void MainWindow::on_pushButton_clicked()
{
    QColor color= QColorDialog::getColor();
    if (color.isValid()) {
        QString estilo= "background-color: rgb(";
        estilo+= QString::number(color.red())+",";
        estilo+= QString::number(color.green())+",";
        estilo+= QString::number(color.blue())+")";
        ui->pushButton->setStyleSheet(estilo);
        color_pincel= CV_RGB(color.red(), color.green(), color.blue());
    }
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    radio_pincel= value;
}

void MainWindow::on_horizontalSlider_2_valueChanged(int value)
{
    difum_pincel= value;
}

void MainWindow::on_toolButton_clicked()
{
    on_actionAbrir_imagen_triggered();
}

void MainWindow::on_actionGuardar_triggered()
{
    int fa= foto_activa();
    if (fa!=-1)
        guardar_foto(fa);
}

void MainWindow::on_actionGuardar_como_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        QString nombre= QFileDialog::getSaveFileName(this, "Guardar imagen", QString::fromStdString(foto[fa].nombre), FiltroImagen);
        if (!nombre.isEmpty())
            guardar_foto(fa, nombre.toUtf8().data());
    }
}

void MainWindow::on_actionCerrar_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        if (foto[fa].modificada && preguntar_guardar) {
            QString nombre= QString::fromStdString(foto[fa].nombre);
            nombre= "El archivo " + nombre + " ha sido modificado.\n¿Desea guardarlo?";
            int resp= QMessageBox::question(this, "Archivo modificado", nombre,
                                            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
            if (resp==QMessageBox::Yes)
                guardar_foto(fa);
            else if (resp==QMessageBox::Cancel)
                return;
            else
                foto[fa].modificada= false;
        }
        cerrar_foto(fa);
    }
}

void MainWindow::on_actionPreguntar_si_guardar_triggered()
{
    preguntar_guardar= ui->actionPreguntar_si_guardar->isChecked();
}

void MainWindow::on_actionColor_del_pincel_triggered()
{
    on_pushButton_clicked();
}

void MainWindow::on_actionSeleccionar_todo_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        foto[fa].roi= Rect(0, 0, foto[fa].img.cols, foto[fa].img.rows);
        mostrar(fa);
    }
}

void MainWindow::on_toolButton_4_clicked()
{
    herr_actual= HER_PUNTO;
}

void MainWindow::on_toolButton_5_clicked()
{
    herr_actual= HER_LINEA;
}

void MainWindow::on_toolButton_6_clicked()
{
    herr_actual= HER_SELECCION;
}

void MainWindow::on_toolButton_7_clicked()
{
    herr_actual = HER_RECTANGULO;
}

void MainWindow::on_toolButton_8_clicked()
{
    herr_actual = HER_ELIPSE;
}


void MainWindow::on_actionInvertir_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        int pl= comprobar_primera_libre();
        if (pl!=-1)
            invertir(fa, pl);
    }
}

void MainWindow::on_actionRotar_90_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        int pl= comprobar_primera_libre();
        if (pl!=-1)
            rotar_exacto(fa, pl, 1);
    }
}

void MainWindow::on_actionRotar_180_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        int pl= comprobar_primera_libre();
        if (pl!=-1)
            rotar_exacto(fa, pl, 2);
    }
}

void MainWindow::on_actionRotar_91_triggered()
{
    int fa= foto_activa();
    if (fa!=-1) {
        int pl= comprobar_primera_libre();
        if (pl!=-1)
            rotar_exacto(fa, pl, 3);
    }
}

void MainWindow::on_actionBrillo_contraste_triggered()
{
    if (foto_activa()!=-1) {
        brillocontraste bc(this);
        bc.exec();
    }
}

void MainWindow::on_actionGausiano_triggered()
{
    if (foto_activa()!=-1) {
        suavizados sg(1, this);
        sg.exec();
    }
}

void MainWindow::on_actionMedia_triggered()
{
    if (foto_activa()!=-1) {
        suavizados sg(2, this);
        sg.exec();
    }
}

void MainWindow::on_actionMediana_triggered()
{
    if (foto_activa()!=-1) {
        suavizados sg(3, this);
        sg.exec();
    }
}

void MainWindow::on_actionMedia_ponderada_triggered()
{
    if (foto_activa()!=-1) {
        int pl= comprobar_primera_libre();
        if (pl!=-1) {
            mediaponderada mp(this);
            mp.exec();
        }
    }
}

void MainWindow::on_actionRotar_imagen_triggered()
{
    if (foto_activa()!=-1) {
        rotaravideo rv;
        rv.exec();
    }
}

void MainWindow::on_actionAcerca_de_triggered()
{
    acercade ad;
    ad.exec();
}

void MainWindow::on_actionImagen_media_triggered()
{
    mediadevideo mv(this);
    mv.exec();
}



void MainWindow::on_actionCaptura_de_video_triggered()
{
    QString nombre = QFileDialog::getOpenFileName();
    if (!nombre.isNull())
    {
        AbrirVideo av(nombre.toLatin1().data(), this);
        av.exec();
    }
}

void MainWindow::on_actionGrises_triggered()
{
    // Control de errores y de la última foto activa
    if (foto_activa() != -1 && primera_libre() != -1)
        histograma(foto_activa(), primera_libre(), 3);
}

void MainWindow::on_actionRojos_triggered()
{
    // Control de errores y de la última foto activa
    if (foto_activa() != -1 && primera_libre() != -1)
        histograma(foto_activa(), primera_libre(), 2);
}

void MainWindow::on_actionVerdes_triggered()
{
    // Control de errores y de la última foto activa
    if (foto_activa() != -1 && primera_libre() != -1)
        histograma(foto_activa(), primera_libre(), 1);
}

void MainWindow::on_actionAzul_triggered()
{
    // Control de errores y de la última foto activa
    if (foto_activa() != -1 && primera_libre() != -1)
        histograma(foto_activa(), primera_libre(), 0);
}

void MainWindow::on_actionCopiar_a_nueva_triggered()
{
    int fa=foto_activa();
    int pl = primera_libre();

    if (fa != -1 && pl != -1){
        crear_nueva(pl, foto[fa].img(foto[fa].roi).clone());
    }

}

void MainWindow::on_actionPinchar_triggered()
{
    if (foto_activa() != -1){
       Pinchar pi(foto_activa());
       pi.exec();
    }
}

void MainWindow::on_toolButton_9_clicked()
{
    herr_actual = HER_ARCOIRIS;
}

void MainWindow::on_actionArcoiris_triggered()
{
    herr_actual = HER_ARCOIRIS;
    ui->toolButton_9->setChecked(true);
}

void MainWindow::on_actionMatiz_Saturaci_n_Luminosidad_triggered()
{
    if (foto_activa() != -1) {
        MatizSat ms(foto_activa());
        ms.exec();
    }
}

void MainWindow::on_actionBalance_de_blancos_triggered()
{
    int fa = foto_activa();
    int pl = primera_libre();
    if (fa != -1 && pl != -1)
        balance_de_blancos(fa, pl);
}

void MainWindow::on_actionCapturar_de_c_mara_triggered()
{
    if (primera_libre() != -1)
        capturar_de_camara(0, primera_libre());
}

void MainWindow::on_actionEscala_de_color_triggered()
{
    int fa = foto_activa();
    int pl = primera_libre();
    if (fa != -1 && pl != -1)
        escala_color(fa, pl, color_pincel);
}

void MainWindow::on_actionAjuste_lineal_del_histograma_triggered()
{
    if (foto_activa() != -1) {
        ajustelineal al(foto_activa());
        al.exec();
    }
}

void MainWindow::on_actionMovimiento_triggered()
{
    if (primera_libre() != -1)
    {
        QString nombre = QFileDialog::getOpenFileName(this, "Abrir vídeo", ".", QString::fromStdString(FiltroVideo));
        if (!nombre.isNull())
            ver_movimiento(nombre.toLatin1().data(), primera_libre());

    }
}

void MainWindow::on_actionPerspectiva_triggered()
{
    if (foto_activa() != -1)
    {
        perspectiva p(foto_activa());
        p.exec();
    }
}


void MainWindow::on_actionNueva_desde_el_portapapeles_triggered()
{

    QImage qimg = QApplication::clipboard()->image();

    if (qimg.isNull())
    {
        QMessageBox::warning(NULL, "Error al leer del portapapeles", "Lo siento. No hay ninguna imagen en el portapapeles");
        return;
    }

    Mat img;

    if (qimg.format() == QImage::Format_RGB32)
    {
        img = cv::Mat(qimg.height(), qimg.width(), CV_8UC4, (void*)qimg.constBits(), (uint) qimg.bytesPerLine());
        cvtColor(img, img, COLOR_BGRA2BGR);

    } else if (qimg.format() == QImage::Format_RGB888) {
        img = cv::Mat(qimg.height(), qimg.width(), CV_8UC3, (void*)qimg.constBits(), (uint) qimg.bytesPerLine());
        cvtColor(img, img, COLOR_RGB2BGR);

    }

    // En principio no es necesario añadir más formatos

    crear_nueva(primera_libre(), img.clone());

}


void MainWindow::on_actionCopiar_al_portapapeles_triggered()
{

    int fa = foto_activa();
    if (fa != -1)
    {
        Mat img = foto[fa].img;
        Mat roi = img(foto[fa].roi);
        cvtColor(roi, roi, COLOR_BGR2RGB);
        QImage qimg(roi.data, roi.cols, roi.rows, (uint) roi.step, QImage::Format_RGB888);
        QApplication::clipboard()->setImage(qimg);

    } else {
        QMessageBox::warning(this, "Error al guardar en el portapapeles",
                             "Lo siento. No hay ninguna imagen abierta.");
    }
}


void MainWindow::on_actionVer_informaci_n_2_triggered()
{
    if (foto_activa() != -1) {

        ventana v = foto[foto_activa()];

        int ancho = v.img.size().width;
        int alto = v.img.size().height;

        String resolucion = to_string(ancho) + "x" + to_string(alto);

        int canales = v.img.channels(); // C3 -> 3 canales por pixel
        int prof = 8; // 8U -> 8 bits por canal
        int bit_pixel = prof * canales; //8UC3 -> 8U*C3 == 24 bits/pixel

        String tam = to_string((ancho * alto * prof)/8) + " bytes";

        QString info = QString::fromStdString("Ubicación: " + v.nombre +
                                                     "\n\n Resolución: " + resolucion +
                                                     "\n Ancho: " + to_string(ancho) + " píxeles" +
                                                     "\n Alto: " + to_string(alto) + " píxeles" +
                                                     "\n\n Profundidad: 8U" +
                                                     "\n Canales: C3" +
                                                     "\n Bits/pixel: " + to_string(bit_pixel) +
                                                     "\n\n Memoria ocupada: " + tam);

        QMessageBox::information (this, "Información", info);


    }  else {
        QMessageBox::warning(this, "Error al ver información de la imagen",
                             "Lo siento. No hay ninguna imagen abierta.");
    }
}



void MainWindow::on_toolButton_10_clicked()
{
    herr_actual = HER_RELLENAR;
}

void MainWindow::on_actionRellenar_triggered()
{
    herr_actual = HER_RELLENAR;
    ui->toolButton_10->setChecked(true);
}

void MainWindow::on_toolButton_11_clicked()
{
    herr_actual = HER_SUAVIZAR;
}

void MainWindow::on_actionSuavizado_triggered()
{
    herr_actual = HER_SUAVIZAR;
    ui->toolButton_11->setChecked(true);
}


void MainWindow::on_actionPerfilado_triggered()
{
    int fa = foto_activa();
    if (fa != -1){
        perfilado pe(fa, this);
        pe.exec();
    }
}

void MainWindow::on_actionCopiar_con_efectos_triggered()
{
    CopiarConEfecto cce(this);
    cce.exec();
}

void MainWindow::on_actionColor_falso_2_triggered()
{
    int fa = foto_activa();
    if (fa != -1){
        int pl= comprobar_primera_libre();
        if (pl!=-1){
            colorfalso cf(fa, pl, this);
            cf.exec();
        }
    }
}

void MainWindow::on_toolButton_12_clicked()
{
    herr_actual = HER_TRAZO;
}

void MainWindow::on_actionTrazo_triggered()
{
    herr_actual = HER_TRAZO;
    ui->toolButton_12->setChecked(true);
}



void MainWindow::on_actionTexto_triggered()
{
    int fa = foto_activa();
    if (fa != -1){
        int pl= comprobar_primera_libre();
        if (pl!=-1){
            texto te(fa, this);
            te.exec();
        }
    }
}

void MainWindow::on_actionBajorrelieve_triggered()
{
    int fa = foto_activa();
    if (fa != -1){
        int pl= comprobar_primera_libre();
        if (pl!=-1){
            bajorrelieve bj(fa, pl, this);
            bj.exec();
        }
    }
}

void MainWindow::on_actionStar_Wars_triggered()
{
    int fa = foto_activa();
    if (fa != -1){
        starwars sw(this);
        sw.exec();
    }

}
