#ifndef ABRIRVIDEO_H
#define ABRIRVIDEO_H

#include <QDialog>
#include <opencv2/opencv.hpp>
using namespace cv;

namespace Ui {
class AbrirVideo;
}

class AbrirVideo : public QDialog
{
    Q_OBJECT

public:
    explicit AbrirVideo(std::string nombre, QWidget *parent = nullptr);
    ~AbrirVideo();

private slots:
    void on_horizontalSlider_valueChanged(int value);

    void on_spinBox_valueChanged(int arg1);

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::AbrirVideo *ui;
    VideoCapture vc;
};

#endif // ABRIRVIDEO_H
