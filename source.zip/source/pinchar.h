#ifndef PINCHAR_H
#define PINCHAR_H

#include <QDialog>
#include "imagenes.h"

namespace Ui {
class Pinchar;
}

class Pinchar : public QDialog
{
    Q_OBJECT

public:
    explicit Pinchar(int nfoto, QWidget *parent = nullptr);
    ~Pinchar();
    Point centro;
    void actualizar();

private slots:
    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_2_valueChanged(int value);

    void on_checkBox_clicked();

    void on_Pinchar_accepted();

    void on_Pinchar_rejected();

private:
    Ui::Pinchar *ui;

    int nfoto;
    double grado;
    double tam;

};

#endif // PINCHAR_H
