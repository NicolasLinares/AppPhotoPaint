#ifndef PERFILADO_H
#define PERFILADO_H

#include <QDialog>

namespace Ui {
class perfilado;
}

class perfilado : public QDialog
{
    Q_OBJECT

public:
    explicit perfilado(int nfoto, QWidget *parent = nullptr);
    ~perfilado();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::perfilado *ui;
    int nfoto;

private slots:
    void on_horizontalSlider_valueChanged(int value);
    void on_horizontalSlider_2_valueChanged(int value);
    void on_spinBox_valueChanged(int arg1);
    void on_spinBox_2_valueChanged(int arg1);
    void on_checkBox_stateChanged(int arg1);

    void on_buttonBox_accepted();
    void on_buttonBox_rejected();
    void on_perfilado_finished(int result);
};

#endif // PERFILADO_H
