#include "colorfalso.h"
#include "ui_colorfalso.h"

colorfalso::colorfalso(int nfoto, int nres, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::colorfalso)
{
    ui->setupUi(this);
    this->nfoto = nfoto;
    this->nres = nres;
}

colorfalso::~colorfalso()
{
    delete ui;
}

void colorfalso::on_colorfalso_accepted()
{
    // Se obtiene primero el mapa de color deseado
    QString color_map= ui->comboBox->currentText();
    int map;
    if (color_map == "Autumn")
        map = COLORMAP_AUTUMN;
    else if (color_map == "Bone")
        map = COLORMAP_BONE;
    else if (color_map == "Jet")
        map = COLORMAP_JET;
    else if (color_map == "Winter")
        map = COLORMAP_WINTER;
    else if (color_map == "Rainbow")
        map = COLORMAP_RAINBOW;
    else if (color_map == "Ocean")
        map = COLORMAP_OCEAN;
    else if (color_map == "Summer")
        map = COLORMAP_SUMMER;
    else if (color_map == "Spring")
        map = COLORMAP_SPRING;
    else if (color_map == "Cool")
        map = COLORMAP_COOL;
    else if (color_map == "HSV")
        map = COLORMAP_HSV;
    else if (color_map == "Pink")
        map = COLORMAP_PINK;
    else if (color_map == "Hot")
        map = COLORMAP_HOT;
    else if (color_map == "Parula")
        map = COLORMAP_PARULA;
    else if (color_map == "Magma")
        map = COLORMAP_MAGMA;
    else if (color_map == "Inferno")
        map = COLORMAP_INFERNO;
    else if (color_map == "Plasma")
        map = COLORMAP_PLASMA;
    else if (color_map == "Viridis")
        map = COLORMAP_VIRIDIS;
    else if (color_map == "Cividis")
        map = COLORMAP_CIVIDIS;
    else if (color_map == "Twilight")
        map = COLORMAP_TWILIGHT;
    else
        map = COLORMAP_TWILIGHT_SHIFTED;

    // y se aplica a la imagen
    ver_colorfalso(nfoto, nres, map);
}

