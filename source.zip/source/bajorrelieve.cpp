#include "bajorrelieve.h"
#include "ui_bajorrelieve.h"
#include "imagenes.h"

bajorrelieve::bajorrelieve(int nfoto, int nres, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::bajorrelieve)
{
    ui->setupUi(this);
    this->nfoto = nfoto;
    this->nres = nres;
    ver_bajorrelieve(nfoto, nres, 0, 1);
}

bajorrelieve::~bajorrelieve()
{
    delete ui;
}

void bajorrelieve::on_horizontalSlider_valueChanged(int value)
{
    if (ui->checkBox->isChecked())
        ver_bajorrelieve(nfoto, nres, ui->dial->value(), value/20.0);
}

void bajorrelieve::on_dial_valueChanged(int value)
{
    if (ui->checkBox->isChecked())
        ver_bajorrelieve(nfoto, nres, value, ui->horizontalSlider->value()/20.0);
}

void bajorrelieve::on_bajorrelieve_accepted()
{
    ver_bajorrelieve(nfoto, nres, ui->dial->value(), ui->horizontalSlider->value()/20.0, true);
    destroyWindow("Bajorrelieve");
}

void bajorrelieve::on_bajorrelieve_rejected()
{
    destroyWindow("Bajorrelieve");
    mostrar(nfoto);
}

void bajorrelieve::on_checkBox_stateChanged(int value)
{
    if (value)
        ver_bajorrelieve(nfoto, nres, ui->dial->value(), ui->horizontalSlider->value()/20.0);
    else
        mostrar(nfoto);
}
