#include "copiarconefecto.h"
#include "ui_copiarconefecto.h"
#include "mainwindow.h"

#include <QMessageBox>
#include <QFileDialog>

CopiarConEfecto::CopiarConEfecto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CopiarConEfecto)
{
    ui->setupUi(this);
}

CopiarConEfecto::~CopiarConEfecto()
{
    delete ui;
}

void CopiarConEfecto::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void CopiarConEfecto::on_spinBox_valueChanged(int value)
{
    this->camara = value;
}

void CopiarConEfecto::on_pushButton_clicked()
{
    this->modo = 0;
    this->camara = ui->spinBox->value();
    ui->pushButton->setChecked(true);
}

void CopiarConEfecto::on_pushButton_2_clicked()
{
    this->modo = 1;
    ui->pushButton_2->setChecked(true);
}

void CopiarConEfecto::on_buttonBox_accepted()
{

    // Se debe elegir el modo de entrada de vídeo para poder ejecutarlo
    if (ui->pushButton->isChecked() || ui->pushButton_2->isChecked())
    {
        // Desactivamos los botones de Ok y Cancel para evitar errores
        ui->buttonBox->setEnabled(false);

        // Obtenemos el códec del vídeo
        int codigocc;
        QString codec= ui->comboBox->currentText();
        if (codec=="DEFAULT")
            codigocc= VideoWriter::fourcc('D','I','V','X');
        else {
            string cadena = codec.toLatin1().data();
            codigocc = VideoWriter::fourcc(cadena[0], cadena[1], cadena[2], cadena[3]);
        }

        // Si se ha seleccionado la opción de buscar vídeo obtenemos su nombre
        if (ui->pushButton_2->isChecked())
        {
            this->nombre_in = QFileDialog::getOpenFileName(this, "Abrir vídeo", ".", QString::fromStdString(FiltroVideo));
            if (this->nombre_in.isEmpty())
            {
                ui->buttonBox->setEnabled(false);
                return;
            }
        }

        // Nombre del fichero resultante
        this->nombre_out = QFileDialog::getSaveFileName();
        if (this->nombre_out.isEmpty())
        {
            ui->buttonBox->setEnabled(false);
            return;
        }

        // Obligamos al usuario a seleccionar al menos un efecto

        String aplicar = "\n";
        if (ui->radioButton->isChecked())
        {
            efectos.push_back(SUAVIZADO_GAUSSIANO);
            aplicar += "    [Suavizado Gaussiano]\n";
        }
        if (ui->radioButton_2->isChecked())
        {
            efectos.push_back(SUAVIZADO_MEDIA);
            aplicar += "    [Suavizado Media]\n";
        }
        if (ui->radioButton_3->isChecked())
        {
            efectos.push_back(SUAVIZADO_MEDIANA);
            aplicar += "    [Suavizado Mediana]\n";
        }

        if (efectos.empty())
        {
            QMessageBox::warning(this, "Error", "Selecciona al menos un efecto.");
            ui->buttonBox->setEnabled(false);
            return;
        }

        ver_copiar_con_efectos(modo, this->nombre_in.toLatin1().data(), camara, this->nombre_out.toLatin1().data(), efectos, aplicar, codigocc);

    }
    else
        QMessageBox::warning(this, "Error", "Selecciona una entrada de vídeo.");

    // Activamos los botones de Ok y Cancel
    ui->buttonBox->setEnabled(true);
}

void CopiarConEfecto::on_buttonBox_rejected()
{
    close();
}





